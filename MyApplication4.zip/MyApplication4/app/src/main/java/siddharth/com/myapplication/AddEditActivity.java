package siddharth.com.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddEditActivity extends AppCompatActivity implements View.OnClickListener{

    private int index = Util.NEW_ITEM;
    private EditText itemPrice;
    private EditText itemQty;
    private EditText itemName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit);

       itemName = (EditText)findViewById(R.id.editText);
        itemQty = (EditText)findViewById(R.id.editText2);
        itemPrice = (EditText)findViewById(R.id.editText3);
        Button save = (Button) findViewById(R.id.button1);
        save.setOnClickListener(this);

        Bundle bundle = getIntent().getExtras();
        if(bundle !=null){
            int index = bundle.getInt(Util.INDEX);
            if(index == Util.NEW_ITEM){

            }
            else{
                    itemName.setText(bundle.getString(Util.ITEM_NAME));
                    itemQty.setText(bundle.getString(Util.ITEM_QTY));
                    itemPrice.setText(bundle.getString(Util.ITEM_PRICE));

            }
        }
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.action_add) {
            Intent intent = new Intent();
            intent.putExtra(Util.ITEM_NAME, itemName.getText().toString());
            intent.putExtra(Util.ITEM_PRICE, itemPrice.getText().toString());
            intent.putExtra(Util.ITEM_QTY, itemQty.getText().toString());
            intent.putExtra(Util.INDEX, index);
            setResult(Util.RES_CODE, intent);
            finish();
        }
        else
        {

        }
    }
}
