package siddharth.com.myapplication;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity{

    private ListView itemsView;
    private ArrayList<String> itemNames = new ArrayList<String>();
    private ArrayList<String> itemPrice = new ArrayList<String>();
    private ArrayList<String> itemQtys = new ArrayList<String>();
    private ArrayAdapter<String> arrayAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        itemsView = (ListView)findViewById(R.id.itemsView);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Shopping app.");
        actionBar.setSubtitle("Manage items.");

        arrayAdapter = new ArrayAdapter<>(this,R.layout.item_row,itemNames);
        itemsView.setAdapter(arrayAdapter);
        itemsView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent();
                intent.putExtra(Util.ITEM_NAME,itemNames.get(i));
                intent.putExtra(Util.ITEM_QTY,itemQtys.get(i));
                intent.putExtra(Util.ITEM_PRICE,itemPrice.get(i));
                startActivity(intent);
                
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem){
        if(menuItem.getItemId() == R.id.action_add)
        {
            Intent intent = new Intent(this, AddEditActivity.class);
            intent.putExtra(Util.INDEX,Util.NEW_ITEM);
            startActivityForResult(intent,Util.REQ_CODE);
        }
        else if(menuItem.getItemId() == R.id.action_register)
        {
//            Intent intent = new Intent(this, addRegisterActivity.Class);
        }
        return super.onOptionsItemSelected(menuItem);
    }
    @Override
    protected void onActivityResult(int request_code,int result_code,Intent data){
        super.onActivityResult(request_code,result_code,data);
        if(request_code==Util.REQ_CODE)
        {
            if(result_code==Util.RES_CODE)
            {
                Bundle bundle = data.getExtras();
                int index = bundle.getInt(Util.INDEX);
                Log.w("ItemName",bundle.getString(Util.ITEM_NAME));
                if(index == Util.NEW_ITEM){
                    itemNames.add(bundle.getString(Util.ITEM_NAME));
                    itemPrice.add(bundle.getString(Util.ITEM_PRICE));
                    itemQtys.add(bundle.getString(Util.ITEM_QTY));

//                    arrayAdapter.add(Util.ITEM_NAME);

                }else{

                }
            }

        }
    }


}
