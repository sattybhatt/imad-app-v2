package siddharth.com.myapplication;

public class Util {

    public static final int REQ_CODE = 232;
    public static final int RES_CODE = 233;
    public static final String ITEM_NAME = "item_name";
    public static final String ITEM_PRICE = "item_price";
    public static final String ITEM_QTY = "item_quantity";
    public static final String INDEX = "index";
    public static final int NEW_ITEM = -1;


}
